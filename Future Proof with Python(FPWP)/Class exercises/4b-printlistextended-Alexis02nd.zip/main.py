
positive_count = 0
negative_count = 0

number_list =list()
for i in range(10):
 numbers = int(input("Enter a number:"))
 number_list.append(numbers)

for num in number_list:
  if num >= 0:
    positive_count += 1
  else:
    negative_count += 1
 
print(number_list) 
print (positive_count)
print (negative_count)
  