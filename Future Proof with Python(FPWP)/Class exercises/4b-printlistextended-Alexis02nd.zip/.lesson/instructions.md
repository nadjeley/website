# Instructions  

Write a program that prompts the user for 10 integers, then prints the following:
- The list of numbers
- The number of positive numbers
- The number of negative numbers

  
  