
languages = ['Arabic', 'Swahili', 'Yoruba', 'Amharic', 'Hausa']

user_guess = input("Can you guess one of the 5 most spoken indigenous languages in Africa? ")
found = False
# add a for loop to check if the guess is in the list and if so, set found to True and print the message


for i in languages:
  if user_guess == i:
    found = True
    print("You got it!", user_guess, "is on the list")
    break
  else:
    print ("Sorry!",user_guess, "is not on the list" )
    break 

  